const express = require('express');
const Request = require('../models/Request');
const router = express.Router();

router.post('/', async (req, res) => {
  try {
    const request = await Request.create(req.body);
    res.status(201).json(request);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/client/:clientId', async (req, res) => {
  const requests = await Request.find({ clientId: req.params.clientId });
  res.json(requests);
});

router.get('/provider/:providerId', async (req, res) => {
  const requests = await Request.find({ providerId: req.params.providerId });
  res.json(requests);
});

module.exports = router;
