# FreightApp Admin Dashboard

Deploy to Vercel and set:
```
REACT_APP_API_URL=https://your-api-url.onrender.com
```