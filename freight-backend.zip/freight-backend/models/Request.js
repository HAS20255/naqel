const mongoose = require('mongoose');
const requestSchema = new mongoose.Schema({
  clientId: mongoose.Schema.Types.ObjectId,
  providerId: mongoose.Schema.Types.ObjectId,
  origin: String,
  destination: String,
  vehicleType: String,
  clientPrice: Number,
  providerCost: Number,
  status: { type: String, enum: ['pending', 'in_transit', 'completed'], default: 'pending' },
  createdAt: { type: Date, default: Date.now },
});
module.exports = mongoose.model('Request', requestSchema);
